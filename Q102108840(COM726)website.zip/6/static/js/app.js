document.addEventListener('DOMContentLoaded', () => {
    const tryOnButton = document.getElementById('try-on-button');

    if (tryOnButton) {
        tryOnButton.addEventListener('click', () => {
            window.location.href = "/try-on";
        });
    }

    const video = document.getElementById('webcam');
    const canvas = document.getElementById('canvas');
    const context = canvas ? canvas.getContext('2d') : null;
    const productSelector = document.getElementById('product-selector');
    const applyButton = document.getElementById('apply-product');

    if (video && context && productSelector && applyButton) {
        if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
            navigator.mediaDevices.getUserMedia({ video: true })
                .then(stream => {
                    video.srcObject = stream;
                })
                .catch(err => {
                    console.error("Error accessing webcam: ", err);
                });
        } else {
            console.error("getUserMedia is not supported by your browser.");
        }

        applyButton.addEventListener('click', () => {
            const selectedOption = productSelector.options[productSelector.selectedIndex];
            const productImage = selectedOption ? selectedOption.dataset.image : '';

            if (productImage) {
                context.drawImage(video, 0, 0, canvas.width, canvas.height);

                const img = new Image();
                img.src = productImage;
                img.onload = () => {
                    context.drawImage(img, 100, 100, 150, 150); // Adjust position and size as needed
                };
            } else {
                console.error("No product image selected.");
            }
        });
    } else {
        console.error("One or more required elements are missing.");
    }
});
